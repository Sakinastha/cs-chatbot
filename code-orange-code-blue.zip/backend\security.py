# backend/security.py

import os
from datetime import datetime, timedelta
from jose import jwt
from passlib.context import CryptContext
from dotenv import load_dotenv

# load the .env just like in main.py
load_dotenv(os.path.join(os.path.dirname(__file__), ".env"))

pwd_ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Pull JWT_SECRET from environment
JWT_SECRET = os.getenv("JWT_SECRET")
if not JWT_SECRET:
    raise RuntimeError("Missing JWT_SECRET in .env")

ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 1440  

def hash_password(plain: str) -> str:
    return pwd_ctx.hash(plain)

def verify_password(plain: str, hashed: str) -> bool:
    return pwd_ctx.verify(plain, hashed)

def create_access_token(data: dict) -> str:
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    # use the exact same JWT_SECRET that main.py loaded
    return jwt.encode(to_encode, JWT_SECRET, algorithm=ALGORITHM)
